import { type FsLike } from './fs.ts';
import { type YamlEngine } from './yaml.ts';
export interface QuarantineRequest {
    home: string;
    profile: string;
    /** The loader entry id to disable (e.g. web-ui-usage). */
    rowId: string;
    /** Why the row is being disabled; recorded in the marker comment. */
    reason: string;
    fs?: FsLike;
    engine?: YamlEngine;
    now?: () => string;
}
export interface QuarantineOutcome {
    ok: boolean;
    /** 'written' — a disabled override row was added; 'already' — the row was already disabled; 'skipped' — refused (live profile / unparseable / not found). */
    phase: 'written' | 'already' | 'skipped';
    path: string;
    message?: string;
}
/** Append a disabled override for one row id; returns the next file text, or undefined when no edit is needed. */
export declare function disabledRowText(existing: string, rowId: string, reason: string, at: string): string | undefined;
/**
 * Quarantine one plugin row: parse-check the patch file first (a broken file
 * is the repair lane's job, not ours), append the disabled override, and
 * report what happened. Never touches a file whose current content fails to
 * parse — that case needs the D-040 quarantine flow instead.
 */
export declare function quarantinePluginRow(request: QuarantineRequest): Promise<QuarantineOutcome>;
