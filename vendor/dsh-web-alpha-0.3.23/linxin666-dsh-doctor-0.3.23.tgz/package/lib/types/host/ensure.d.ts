import type { DoctorPaths } from '../agent/paths.ts';
import type { SupervisorResponse } from '../core/protocol.ts';
/**
 * Lifecycle orchestration for the Doctor supervisor.
 *
 * The supervisor runs as a bounded child of the host that spawned it (with a
 * parent-liveness watch, see agent/supervisor.ts): it dies with the host
 * instead of living as an OS-registered login service. Ensure therefore
 * idempotently retires any legacy service registration, (re)spawns the
 * supervisor child when none answers with the current version, waits for it
 * to answer, and refreshes the rescue capsule when its pinned version is
 * stale. Uninstall marks the supervisor state, removes legacy registrations
 * and the capsule credentials. Every external effect sits behind injectable
 * seams so tests verify the full sequence without spawning real processes.
 * @module @linxin666/dsh-doctor/host
 */
/** Result of one spawned command. */
export interface SpawnResult {
    code: number;
    stdout: string;
    stderr: string;
}
/**
 * Environment for a Node child spawned through `process.execPath`. When the
 * host runs embedded in an Electron desktop app, execPath is the GUI binary:
 * without ELECTRON_RUN_AS_NODE the spawn boots a second GUI instance — the
 * single-instance lock refuses it, the main window is raised and focused on
 * every retry, and the child exits without ever answering (#1382). Plain
 * Node binaries ignore the variable, so it is set unconditionally.
 */
export declare function nodeChildEnv(base?: NodeJS.ProcessEnv): NodeJS.ProcessEnv;
/** Spawn seam: default runs the real process. */
export type SpawnFn = (command: string, args: string[], opts: {
    timeoutMs: number;
    env?: NodeJS.ProcessEnv;
}) => Promise<SpawnResult>;
/** Supervisor IPC seam (throws while the supervisor is down). */
export type StatusFn = () => Promise<SupervisorResponse>;
/** Verdict of one lifecycle verb. */
export interface LifecycleReport {
    ok: boolean;
    code: string;
    message?: string;
    /** Human-readable steps that ran, in order. */
    steps: string[];
}
export interface DoctorLifecycleDeps {
    paths: DoctorPaths;
    /** Absolute path of the package CLI (lib/cli.mjs) driving the supervisor. */
    cliPath: string;
    /** Version of the host half (package.json); capsule staleness compares against it. */
    version: string;
    status: StatusFn;
    /** Mark the supervisor state uninstalling before cleanup. */
    markUninstall?: () => Promise<unknown>;
    /** One-shot command seam (capsule provisioning); tests inject fakes. */
    spawn?: SpawnFn;
    /** Spawn the supervisor as a bounded child of this process; tests inject fakes. */
    spawnSupervisor?: () => void;
    /** Ask an answering-but-stale supervisor to exit (IPC shutdown). */
    shutdown?: () => Promise<unknown>;
    /** Retire a legacy OS service registration; tests inject fakes. */
    removeLegacyService?: () => Promise<boolean>;
    /** Whether the supervisor state is provisioned (token file exists). */
    provisioned?: () => Promise<boolean>;
    /** Whether the rescue capsule is missing or pinned to another doctor/credentials version. */
    capsuleStale?: (currentVersion: string, source?: {
        home: string;
        profile: string;
    }) => Promise<boolean>;
    /** Source profile whose credentials mirror staleness is checked against. */
    source?: {
        home: string;
        profile: string;
    };
    pollAttempts?: number;
    pollDelayMs?: number;
}
export interface DoctorLifecycle {
    ensure(): Promise<LifecycleReport>;
    uninstall(): Promise<LifecycleReport>;
}
/**
 * Default bounded-child spawn: the supervisor runs the current package CLI
 * with a parent-liveness watch on this process. Not detached and unref'd —
 * it joins this host's process group (process-group kills reach it) and it
 * never keeps the host's event loop alive on its own. The child env forces
 * ELECTRON_RUN_AS_NODE so an Electron host binary (desktop app embedding the
 * doctor host) runs the supervisor as headless Node instead of booting a
 * second GUI instance (#1382).
 */
export declare function defaultSpawnSupervisor(deps: DoctorLifecycleDeps): void;
/** True when the supervisor state directory holds the IPC token. */
export declare function defaultProvisioned(paths: DoctorPaths): Promise<boolean>;
/**
 * True when the capsule is absent, pinned to another doctor version, or its
 * mirrored credentials no longer match the current source files (the user
 * changed providers or keys since the last provision).
 */
export declare function defaultCapsuleStale(paths: DoctorPaths, currentVersion: string, source?: {
    home: string;
    profile: string;
}): Promise<boolean>;
/** Run one lifecycle verb; concurrent calls of the same verb share the run. */
export declare function createDoctorLifecycle(deps: DoctorLifecycleDeps): DoctorLifecycle;
/** Retire legacy registrations, (re)spawn the supervisor, then refresh a stale capsule. */
export declare function ensureDoctor(deps: DoctorLifecycleDeps): Promise<LifecycleReport>;
/** Mark the supervisor state, retire legacy registrations, drop capsule credentials. */
export declare function uninstallDoctor(deps: DoctorLifecycleDeps): Promise<LifecycleReport>;
