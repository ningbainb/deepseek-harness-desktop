import { DoctorSupervisor } from './agent/supervisor.ts';
export declare function main(argv?: string[]): Promise<number>;
/**
 * Check if the current module is the direct CLI entry point across platforms.
 * Handles Windows backslashes, drive letters, and relative/absolute paths cleanly.
 */
export declare function isDirectCliRun(metaUrl: string, entryArg?: string | undefined): boolean;
export { DoctorSupervisor };
