export interface LegacyMigrationResult {
    kind: 'noop' | 'migrated' | 'error';
    message?: string;
    targetSpec?: string;
    targetVersion?: string;
}
export interface LegacyMigrationDeps {
    env?: NodeJS.ProcessEnv;
    /** Run one command array without a shell. */
    run?: (args: string[], env: NodeJS.ProcessEnv) => Promise<{
        code: number | null;
        output: string;
    }>;
    exists?: (path: string) => boolean;
    fetch?: (url: string) => Promise<{
        ok: boolean;
        json(): Promise<unknown>;
    }>;
    targetVersion?: string;
    now?: () => string;
}
/** Build the full old package spec from the profile's recorded dependency spec. */
export declare function fullLegacySpec(name: string, spec: string): string;
/**
 * Run the deterministic legacy aggregate migration through the official CLI.
 * Returns noop when there is nothing to migrate or the current package is not
 * yet available; returns error with a diagnostic message otherwise.
 */
export declare function migrateLegacyAggregate(home: string, profile: string, dshPath: string, options?: LegacyMigrationDeps): Promise<LegacyMigrationResult>;
