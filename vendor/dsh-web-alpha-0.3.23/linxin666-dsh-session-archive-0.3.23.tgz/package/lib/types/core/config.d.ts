/**
 * Configuration shape and validation for dsh-session-archive, shared by the
 * host schema and the client settings form. Pure logic.
 * @module @linxin666/dsh-session-archive/core/config
 */
export interface SessionArchiveConfig {
    enabled?: boolean;
    /** Auto-archive sessions inactive for more than this many days. Default off. */
    autoArchiveEnabled?: boolean;
    /** Inactivity threshold in days for auto-archive (1-3650). */
    autoArchiveDays?: number;
    /** Physically delete archived sessions older than this many days after archive time. Default off. */
    autoDeleteEnabled?: boolean;
    /** Archive retention in days for auto-delete (1-3650). */
    autoDeleteDays?: number;
    /** Scheduler cadence in minutes (15-1440). */
    checkIntervalMin?: number;
}
export interface ResolvedAutoConfig {
    enabled: boolean;
    autoArchiveEnabled: boolean;
    autoArchiveDays: number;
    autoDeleteEnabled: boolean;
    autoDeleteDays: number;
    checkIntervalMin: number;
}
export declare const AUTO_ARCHIVE_DAYS_MIN = 1;
export declare const AUTO_ARCHIVE_DAYS_MAX = 3650;
export declare const AUTO_DELETE_DAYS_MIN = 1;
export declare const AUTO_DELETE_DAYS_MAX = 3650;
export declare const CHECK_INTERVAL_MIN_MIN = 15;
export declare const CHECK_INTERVAL_MIN_MAX = 1440;
export declare const DEFAULT_AUTO_CONFIG: ResolvedAutoConfig;
/** Validate one day-threshold field; returns the rounded value or undefined when invalid. */
export declare function validateDays(value: unknown, min: number, max: number): number | undefined;
/**
 * Coerce a raw config into resolved values. Invalid or out-of-range fields
 * fall back to defaults — the settings UI validates before saving, and this
 * guards profile-patch hand-written values.
 */
export declare function resolveAutoConfig(config?: SessionArchiveConfig): ResolvedAutoConfig;
