import type { Context } from '@deepseek-ai/cordis';
import type { SettingsNamespace } from '@deepseek-ai/dsh-settings';
import z from 'schemastery';
import type { SessionArchiveConfig } from './core/config.ts';
export declare const name = "dsh-session-archive";
export declare const inject: string[];
export declare const SESSION_ARCHIVE_SETTINGS_NAMESPACE: SettingsNamespace;
export declare const Config: z<SessionArchiveConfig>;
export declare const apply: (ctx: Context, config?: SessionArchiveConfig) => void;
