/**
 * dsh-session-archive browser half — takes over the official
 * `archived-sessions` settings section instead of seating a parallel
 * first-level entry. The official
 * `@deepseek-ai/dsh-client-ui-settings-unarchive-sessions` page owns that
 * section id at order 25, and `dsh-web-all` retires its row, so exactly one
 * 「已归档会话」 nav entry remains and it carries both the native restore
 * behaviour (the section opens on the archived view) and this plugin's batch,
 * delete and retention surfaces. All session enumeration and mutation happens
 * in the host half over loopback-fenced routes; this bundle renders the
 * inventory document and drives the batch pipelines.
 * @module @linxin666/dsh-session-archive/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { SettingsScope, SettingsScopeSpec } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { SessionArchiveConfig } from '../core/config.ts';
/** Required services. */
export declare const inject: string[];
export type { SessionArchiveFace } from './SessionArchiveCard.tsx';
export type { SessionArchiveConfig };
declare module '@deepseek-ai/cordis' {
    interface Context {
        /**
         * Optional rc.6 compatibility binder provided by dsh-web-settings;
         * absent when that group plugin is not installed, so callers fall back to
         * the official settings scope.
         */
        webUiSettings?: {
            bind<S>(spec: SettingsScopeSpec<S>): SettingsScope<S>;
        };
    }
}
/**
 * Client plugin body: register dictionaries and seat the settings section.
 * The controller and store live with the apply body, so the last inventory
 * renders instantly when the section is reopened.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
