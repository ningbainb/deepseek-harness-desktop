/**
 * Skill center list filtering (pure, browser half): the search box and the
 * workspace picker are two axes over the same grouped payload, so the
 * matching rules live here and stay unit-testable without a DOM.
 */
import type { GroupPayload, SkillEntry } from './api.ts';
/** The list tab's filter state. */
export interface SkillListFilter {
    /** Selected workspace root, or 'all' for no workspace restriction. */
    workspace: string;
    /** Raw search text; trimmed and lowercased before matching. */
    query: string;
}
/**
 * Match rank of one skill against a lowercased needle: 0 when the name hits,
 * 1 when only the description hits, undefined when neither does. An empty
 * needle matches everything at rank 0.
 */
export declare function matchRank(skill: SkillEntry, needle: string): 0 | 1 | undefined;
/**
 * Apply both axes to a payload's groups: workspace filter first, then the
 * query (name hits ranked before description hits, stable within a rank).
 * Empty groups are dropped so the caller renders only what has content.
 * @param groups - host payload groups in host order.
 * @param filter - workspace + query.
 * @returns the visible groups; the input is never mutated.
 */
export declare function selectGroups(groups: readonly GroupPayload[], filter: SkillListFilter): GroupPayload[];
