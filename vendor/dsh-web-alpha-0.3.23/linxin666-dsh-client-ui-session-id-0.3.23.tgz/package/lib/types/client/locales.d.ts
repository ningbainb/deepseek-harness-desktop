/**
 * Locale dictionaries for the session-id plugin. `zh` is the key-set source of
 * truth; `en` keeps a full key-for-key mirror (packages/AGENTS.md bilingual
 * rules). Registered through ctx.locale.register(NS, { zh, en }).
 */
/** Simplified Chinese dictionary (key-set source of truth). */
export declare const zh: {
    'entry.label': string;
    'panel.title': string;
    'panel.empty': string;
    'panel.noMatches': string;
    'panel.search.placeholder': string;
    'panel.search.aria': string;
    'panel.close': string;
    'panel.copy': string;
    'panel.copied': string;
    'panel.copyFailed': string;
    'panel.current': string;
    'panel.updatedAt': string;
    'panel.time.now': string;
    'panel.time.minutes': string;
    'panel.time.hours': string;
    'panel.time.days': string;
};
/** The session-id namespace key union. */
export type SessionIdKey = keyof typeof zh;
/** English dictionary, key-for-key complete against zh. */
export declare const en: Record<SessionIdKey, string>;
