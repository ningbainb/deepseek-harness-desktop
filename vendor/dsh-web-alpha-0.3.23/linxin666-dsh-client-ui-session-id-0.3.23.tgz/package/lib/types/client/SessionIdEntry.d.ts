import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import { type SessionListReadSource } from './SessionIdPanel.tsx';
/** Entry props: the footer seat's column state + injected list source + locale seat. */
export type SessionIdEntryProps = PropsLocale<'session-id'> & {
    /** Whether the sidebar renders wide content (false = 56px rail). */
    wide: boolean;
    /** The sessions-list read face (ctx.sessions.list wrapped by the plugin). */
    list: SessionListReadSource;
};
/**
 * Render the session-id seat trigger and panel.
 * @param props - composed slot props.
 * @returns the trigger and, when open, the panel portal.
 */
export declare function SessionIdEntry({ wide, list, t }: SessionIdEntryProps): import("react").JSX.Element;
