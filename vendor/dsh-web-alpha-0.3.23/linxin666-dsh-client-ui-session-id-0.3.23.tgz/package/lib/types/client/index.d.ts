/**
 * Session-id plugin — browser half. Registers the `session-id` dictionaries
 * and the sidebar-foot trigger (into the ui-sidebar-declared
 * `sidebar.footer.action` list slot) that opens the session-id panel. The
 * panel lists every session with its full id and a copy button.
 *
 * Export discipline (packages/AGENTS.md): the /client surface carries only
 * what cordis loading needs plus types.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import { type SessionIdKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Session-id surface copy. */
        'session-id': SessionIdKey;
    }
}
/** Services required by this plugin. */
export declare const inject: string[];
/**
 * Register the session-id surface.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
export type { SessionIdEntryProps } from './SessionIdEntry.tsx';
export type { SessionIdKey } from './locales.ts';
export type { SessionListReadSource, SessionIdPanelProps } from './SessionIdPanel.tsx';
