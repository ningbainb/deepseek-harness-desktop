/**
 * Inline SVG icons for the session-id plugin (16px stroke style matching the
 * shell's nav icons; sized via className where a smaller variant is needed).
 */
import type { SVGProps } from 'react';
/** An ID-card / identifier glyph for the seat trigger and panel title. */
export declare function SessionIdIcon(props: SVGProps<SVGSVGElement>): import("react").JSX.Element;
/** Copy glyph. */
export declare function CopyIcon(props: SVGProps<SVGSVGElement>): import("react").JSX.Element;
/** Check glyph for the transient copied state. */
export declare function CheckIcon(props: SVGProps<SVGSVGElement>): import("react").JSX.Element;
/** Close glyph for the panel header. */
export declare function CloseIcon(props: SVGProps<SVGSVGElement>): import("react").JSX.Element;
