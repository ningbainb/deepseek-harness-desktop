import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionListState } from '@deepseek-ai/dsh-api-session-controller/client';
/** The sessions-list read face injected by the plugin (ObservableSnapshot). */
export type SessionListReadSource = {
    getSnapshot(): SessionListState;
    subscribe(fn: () => void): () => void;
};
/** Panel props: the list source + the locale seat. */
export type SessionIdPanelProps = PropsLocale<'session-id'> & {
    list: SessionListReadSource;
    onClose: () => void;
};
/**
 * Render the session-id panel body.
 * @param props - injected list source + locale seat + close callback.
 * @returns the modal panel.
 */
export declare function SessionIdPanel({ list, onClose, t }: SessionIdPanelProps): import("react").JSX.Element;
