/**
 * Plugin-owned settings document — the switches the browser settings panel
 * exposes, stored next to the browsing history so both follow the same rules:
 * they survive the browser process and DSH restarts.
 *
 * Every field is optional on disk and falls back to a default, so a hand-edited
 * or older file never breaks startup; an unreadable file is treated as "all
 * defaults" rather than an error.
 * @module dsh-browser/browser-electron/settings-store
 */
import type { BrowserChannel } from './system-browser.js';
/** Vision/operation strategy the provider prefers when the model can see. */
export type VisionStrategy = 'auto' | 'nonVisual';
/**
 * Whether a launched browser gets a window.
 *
 * Split from {@link VisionStrategy} because these answer different questions: that one is how the
 * agent examines a page, this one is whether the browser has anywhere to draw.
 */
export type HeadlessMode = 'auto' | 'headless' | 'windowed';
/** Every value {@link HeadlessMode} accepts, for validation and the settings UI. */
export declare const HEADLESS_MODES: readonly ["auto", "headless", "windowed"];
/** The full settings document, with every field resolved. */
export interface BrowserSettings {
    /** Persistent browsing history (visited pages). */
    readonly history: {
        readonly enabled: boolean;
        readonly maxEntries: number;
        readonly maxAgeDays: number;
    };
    /** Login-state retention: cookies and the browser profile. */
    readonly cookies: {
        readonly persist: boolean;
    };
    /** Presentation behaviour. */
    readonly ui: {
        /** Auto-expand the side panel once per task, then leave the user alone. */
        readonly autoExpandOnce: boolean;
        /** Release the browser when its session ends, instead of waiting for a close. */
        readonly closeWithSession: boolean;
        /** Show the synthetic cursor/click feedback while the agent operates. */
        readonly virtualCursor: boolean;
    };
    /** Visual vs non-visual operation strategy. */
    readonly vision: {
        readonly strategy: VisionStrategy;
    };
    /** Which browser binary carries the agent's pages. */
    readonly browser: {
        readonly channel: BrowserChannel;
        /**
         * Whether the browser gets a window.
         *
         * `auto` (the default) launches headless when the process has no display — no `DISPLAY` and no
         * `WAYLAND_DISPLAY` — and with a window otherwise. That combination is what makes the plugin
         * work under systemd, in a container, or on an SSH-only server while leaving desktop users
         * with the visible window they expect. `true` forces headless (CI, screenshot-only servers);
         * `false` forces a window, so a misconfigured display fails loudly instead of silently
         * degrading into a browser nobody can see.
         *
         * Reported as issue #32: as a systemd service there is no display, Chromium exits with
         * "could not connect to display", and every `dsh_browser_*` call failed with "exited
         * immediately after launch".
         */
        readonly headless: HeadlessMode;
    };
    /** Whether the agent may read cookies / export login state. */
    readonly credentials: {
        readonly allowRead: boolean;
    };
    /**
     * What the agent is allowed to DO, as opposed to what it may look at.
     *
     * These are OPERATOR switches: the settings panel is not reachable from the model, so a
     * value here refuses whatever the model asks for, and no tool can lift it. That is what
     * separates them from `dsh_browser_restrict`, which is the model's own soft guardrail. All
     * three default to on, which is the documented out-of-the-box behaviour.
     */
    readonly actions: {
        /** Run arbitrary page scripts in the active tab (`dsh_browser_execute`). */
        readonly allowExecute: boolean;
        /** Download a URL to disk (`dsh_browser_download`). */
        readonly allowDownload: boolean;
        /** Write cookies — importing login state (`dsh_browser_auth` restore). */
        readonly allowCredentialWrite: boolean;
    };
}
/** Defaults for every switch: the documented out-of-the-box behaviour. */
export declare const DEFAULT_SETTINGS: BrowserSettings;
/**
 * Absolute path of the settings file, beside the browser profile and the
 * browsing history.
 * @returns the settings file path.
 */
export declare function settingsPath(): string;
/**
 * The channels a settings document may name.
 *
 * Exported so the log line and the error message can quote the same set the parser accepts: a
 * message that lists a value the code rejects (or omits one it takes) is worse than no message.
 */
export declare const BROWSER_CHANNELS: readonly ["chrome", "edge", "auto", "bundled", "sidebar"];
/**
 * Resolve a raw settings document (already parsed, shape unknown) into the full
 * document, field by field. Unknown keys are dropped: the file is not a place to
 * smuggle configuration.
 * @param raw - the parsed file contents.
 * @returns the resolved settings.
 */
export declare function resolveSettings(raw: unknown, warn?: (message: string) => void): BrowserSettings;
/**
 * File-backed settings with an in-memory snapshot. Reads re-stat the file so an
 * edit from another process (or the settings panel writing through a second
 * code path) is picked up without a restart; writes are atomic enough for a
 * single-writer plugin and never throw at the caller.
 */
export declare class SettingsStore {
    private readonly file;
    private readonly log?;
    private cached;
    /** Last observed mtime, used to invalidate the cache on external edits. */
    private cachedMtimeMs;
    /**
     * @param file - settings file path (defaults beside the browser profile).
     */
    constructor(file?: string, log?: ((message: string) => void) | undefined);
    /** Path this store reads and writes. */
    path(): string;
    /**
     * Current settings, re-read when the file changed on disk.
     * @returns the resolved settings document.
     */
    get(): BrowserSettings;
    /**
     * Merge a partial patch into the stored document and persist it.
     * @param patch - the fields to change (unknown keys are ignored).
     * @returns the settings after the merge.
     */
    update(patch: unknown): BrowserSettings;
}
/**
 * Replace a file's contents atomically: write a sibling temporary file, then rename it over
 * the target.
 *
 * `writeFileSync(target, …)` truncates and rewrites in place, so a crash, a full disk or an
 * antivirus lock in the middle leaves HALF a JSON document. That used to be silent: the reader
 * resolved an unparseable file to the defaults, so a torn write flipped `credentials.allowRead`
 * and the action switches back ON, and the next successful update wrote those defaults to disk
 * for good. The read side no longer does that (see {@link SETTINGS_WHEN_UNREADABLE}) — but the
 * write side still has to stop producing torn files at all, because half a document is not
 * something this plugin should ever leave behind.
 *
 * The rename is the commit point: a reader sees either the old document or the new one,
 * never a partial one. It stays in the same directory so the rename is atomic on Windows
 * as well as POSIX (`renameSync` maps to MoveFileEx there: same-volume replaces are
 * atomic, cross-volume ones are not supported at all).
 *
 * The temporary is written with a unique suffix rather than a fixed `.tmp`, so two writers
 * (the settings panel and a second DSH process) cannot rename each other's half-written
 * file into place. Shared with the history store, which had the same hole.
 * @param file - the target path.
 * @param contents - the complete new document.
 */
export declare function writeFileAtomic(file: string, contents: string): void;
