/**
 * Model-facing browser tools over `ctx.browser`: `dsh_browser_open`,
 * `dsh_browser_snapshot`, `dsh_browser_execute`, `dsh_browser_content`,
 * `dsh_browser_screenshot`, and tab management (`dsh_browser_list_tabs`,
 * `dsh_browser_switch_tab`, `dsh_browser_close_tab`, `dsh_browser_reset`).
 *
 * The tool layer owns only the model-facing schema, argument validation, and
 * result formatting — never provider selection or page driving, which belong
 * to the seam. Session lifecycle is owned here at the plugin level: each
 * calling task (a DSH session) gets its own browser session — the first
 * `dsh_browser_open` (or any tool when no session exists) opens it, and later
 * tools in the same task reuse it. Concurrent tasks therefore never fight
 * over tabs, history, or navigation state.
 * @module dsh-browser/tool-browser
 */
import type { Context } from '@deepseek-ai/cordis';
import type { BrowserSessionId } from '../browser/types.js';
/** Plugin name used by loader diagnostics. */
export declare const name = "tool-browser";
/** The tool registry, browser seam, and system-prompt registry this tool layer consumes. */
export declare const inject: string[];
/** Plugin config: tool timeouts and session defaults. */
export interface Config {
    /** Cooperative tool-call budget in ms. Default 60000. */
    readonly timeoutMs?: number;
    /** Whether to offer tab-management tools. Default true. */
    readonly tabTools?: boolean;
    /** Optional initial allow-list of browser tool names; other tools are refused. */
    readonly allowedActions?: readonly string[];
}
/**
 * Guard one browser tool call against the active restriction. Refuses calls
 * not on the allow-list when a restriction is in effect.
 * @param state - the calling context's tool state.
 * @param toolName - the browser tool about to run.
 */
/**
 * Tools that only observe, plus the ones that undo a restriction.
 *
 * Never subject to an allow-list: restricting what the agent may *do* must not also
 * blind it or trap it, and the tool descriptions promise as much. dsh_browser_restrict
 * is in here so a task that restricted everything can still lift it.
 */
export declare const READ_ONLY_TOOLS: ReadonlySet<string>;
/** Register all browser tools with `ctx.tools`. */
export declare function apply(ctx: Context, config?: Config): void;
/** Test hook: inspect and reset session mappings across every live plugin apply. */
export declare const internals: {
    /** A copy of every live apply's per-task session map (task key -> provider session id). */
    readonly sessions: ReadonlyMap<string, BrowserSessionId>;
    /** Drop one task's mapping (across live applies) without closing the provider session. */
    clearSession(key?: string): void;
};
