/**
 * Plugin-owned settings document — the switches the browser settings panel
 * exposes, stored next to the browsing history so both follow the same rules:
 * they survive the browser process and DSH restarts.
 *
 * Every field is optional on disk and falls back to a default, so a hand-edited
 * or older file never breaks startup; an unreadable file is treated as "all
 * defaults" rather than an error.
 * @module dsh-browser/browser-electron/settings-store
 */

import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { dirname, join } from 'node:path'
import type { BrowserChannel } from './system-browser.js'

/** Vision/operation strategy the provider prefers when the model can see. */
export type VisionStrategy = 'auto' | 'nonVisual'

/**
 * Whether a launched browser gets a window.
 *
 * Split from {@link VisionStrategy} because these answer different questions: that one is how the
 * agent examines a page, this one is whether the browser has anywhere to draw.
 */
export type HeadlessMode = 'auto' | 'headless' | 'windowed'

/** Every value {@link HeadlessMode} accepts, for validation and the settings UI. */
export const HEADLESS_MODES = ['auto', 'headless', 'windowed'] as const

/** The full settings document, with every field resolved. */
export interface BrowserSettings {
  /** Persistent browsing history (visited pages). */
  readonly history: {
    readonly enabled: boolean
    readonly maxEntries: number
    readonly maxAgeDays: number
  }
  /** Login-state retention: cookies and the browser profile. */
  readonly cookies: {
    readonly persist: boolean
  }
  /** Presentation behaviour. */
  readonly ui: {
    /** Auto-expand the side panel once per task, then leave the user alone. */
    readonly autoExpandOnce: boolean
    /** Release the browser when its session ends, instead of waiting for a close. */
    readonly closeWithSession: boolean
    /** Show the synthetic cursor/click feedback while the agent operates. */
    readonly virtualCursor: boolean
  }
  /** Visual vs non-visual operation strategy. */
  readonly vision: {
    readonly strategy: VisionStrategy
  }
  /** Which browser binary carries the agent's pages. */
  readonly browser: {
    readonly channel: BrowserChannel
    /**
     * Whether the browser gets a window.
     *
     * `auto` (the default) launches headless when the process has no display — no `DISPLAY` and no
     * `WAYLAND_DISPLAY` — and with a window otherwise. That combination is what makes the plugin
     * work under systemd, in a container, or on an SSH-only server while leaving desktop users
     * with the visible window they expect. `true` forces headless (CI, screenshot-only servers);
     * `false` forces a window, so a misconfigured display fails loudly instead of silently
     * degrading into a browser nobody can see.
     *
     * Reported as issue #32: as a systemd service there is no display, Chromium exits with
     * "could not connect to display", and every `dsh_browser_*` call failed with "exited
     * immediately after launch".
     */
    readonly headless: HeadlessMode
  }
  /** Whether the agent may read cookies / export login state. */
  readonly credentials: {
    readonly allowRead: boolean
  }
  /**
   * What the agent is allowed to DO, as opposed to what it may look at.
   *
   * These are OPERATOR switches: the settings panel is not reachable from the model, so a
   * value here refuses whatever the model asks for, and no tool can lift it. That is what
   * separates them from `dsh_browser_restrict`, which is the model's own soft guardrail. All
   * three default to on, which is the documented out-of-the-box behaviour.
   */
  readonly actions: {
    /** Run arbitrary page scripts in the active tab (`dsh_browser_execute`). */
    readonly allowExecute: boolean
    /** Download a URL to disk (`dsh_browser_download`). */
    readonly allowDownload: boolean
    /** Write cookies — importing login state (`dsh_browser_auth` restore). */
    readonly allowCredentialWrite: boolean
  }
}

/** Defaults for every switch: the documented out-of-the-box behaviour. */
export const DEFAULT_SETTINGS: BrowserSettings = {
  history: { enabled: true, maxEntries: 5_000, maxAgeDays: 90 },
  cookies: { persist: true },
  ui: { autoExpandOnce: true, closeWithSession: false, virtualCursor: true },
  vision: { strategy: 'auto' },
  // Bundled by default: it needs nothing installed, and on the desktop the carrier
  // is the sidebar anyway. Choosing a system browser is an explicit opt-in because
  // it starts a real Chrome/Edge with its own profile.
  browser: { channel: 'bundled', headless: 'auto' },
  credentials: { allowRead: true },
  actions: { allowExecute: true, allowDownload: true, allowCredentialWrite: true },
}

/**
 * Absolute path of the settings file, beside the browser profile and the
 * browsing history.
 * @returns the settings file path.
 */
export function settingsPath(): string {
  const home = process.env.DSH_HOME ?? join(homedir(), '.dsh')
  return join(home, 'dsh-builtin-browser-host', 'settings.json')
}

/** Coerce one boolean field, keeping the default when absent or mistyped. */
function bool(value: unknown, fallback: boolean): boolean {
  return typeof value === 'boolean' ? value : fallback
}

/**
 * Coerce one boolean field that GATES A CAPABILITY.
 *
 * The difference from {@link bool} is what a mistyped value means. Absent still takes the
 * default — a document written before the switch existed is the documented behaviour. But
 * present-and-not-a-boolean is a document this code cannot read, and for a switch that gates
 * something the operator chose to limit, unreadable resolves to OFF. `bool`'s fallback made
 * `"false"` (a string), `null` (a truncated write) and `1` all mean the same as `true`, so a
 * single dropped byte reopened every capability that had been turned off.
 * @param value - the raw value from the settings document.
 * @param fallback - the default, used only when the field is absent.
 * @returns the value when it is a boolean, `false` when it is anything else.
 */
function gate(value: unknown, fallback: boolean): boolean {
  if (value === undefined) return fallback
  return value === true
}

/**
 * What an unreadable document resolves to.
 *
 * Only the capability gates are refused; everything else keeps its default. The distinction is
 * deliberate: refusing history, presentation or browser choice would punish the user for a
 * corrupt file without protecting anything, while refusing the gates is the whole point —
 * "the operator's intent cannot be read" must not resolve to "the operator permits".
 */
const SETTINGS_WHEN_UNREADABLE: BrowserSettings = {
  ...DEFAULT_SETTINGS,
  credentials: { allowRead: false },
  actions: { allowExecute: false, allowDownload: false, allowCredentialWrite: false },
}

/**
 * The channels a settings document may name.
 *
 * Exported so the log line and the error message can quote the same set the parser accepts: a
 * message that lists a value the code rejects (or omits one it takes) is worse than no message.
 */
export const BROWSER_CHANNELS = ['chrome', 'edge', 'auto', 'bundled', 'sidebar'] as const

/**
 * Coerce the headless mode, keeping `auto` when the value is not one of the known choices.
 *
 * Booleans are accepted as a convenience because "headless: true" is what anyone writing this by
 * hand would try first, and rejecting it over a type difference would be pedantry: `true` maps to
 * `headless`, `false` to `windowed`. Anything else is reported rather than silently defaulted,
 * for the same reason as {@link resolveChannel}: a discarded value and an honoured one must not
 * look alike.
 * @param value - the raw value from the settings document.
 * @param warn - where to report a discarded value.
 * @returns a valid mode.
 */
function resolveHeadless(value: unknown, warn?: (message: string) => void): HeadlessMode {
  if (value === undefined) return DEFAULT_SETTINGS.browser.headless
  if (value === true) return 'headless'
  if (value === false) return 'windowed'
  if (typeof value === 'string' && (HEADLESS_MODES as readonly string[]).includes(value)) {
    return value as HeadlessMode
  }
  warn?.(
    `dsh-builtin-browser: browser.headless ${JSON.stringify(value)} is not a known mode, so the `
    + `default "${DEFAULT_SETTINGS.browser.headless}" was used instead. Expected one of: `
    + `${HEADLESS_MODES.join(', ')} (or a boolean).`,
  )
  return DEFAULT_SETTINGS.browser.headless
}

/**
 * Coerce the browser channel, keeping the default when it is not one of the
 * known choices. A hand-edited typo must not silently select a different browser.
 *
 * Coercing is right; coercing QUIETLY is not. A typo and "the setting did nothing" look exactly
 * the same to whoever typed it, which is why every discarded value is reported.
 * @param value - the raw value from the settings document.
 * @param warn - where to report a discarded value, when the caller has somewhere to put it.
 * @returns a valid channel.
 */
function resolveChannel(value: unknown, warn?: (message: string) => void): BrowserChannel {
  // Absent is the ordinary case, not a mistake: a document that never mentioned the channel gets
  // the default without a word.
  if (value === undefined) return DEFAULT_SETTINGS.browser.channel
  if ((BROWSER_CHANNELS as readonly unknown[]).includes(value)) return value as BrowserChannel
  warn?.(
    `dsh-builtin-browser: browser.channel ${JSON.stringify(value)} is not a known channel, so the `
    + `default "${DEFAULT_SETTINGS.browser.channel}" was used instead. Expected one of: `
    + `${BROWSER_CHANNELS.join(', ')}.`,
  )
  return DEFAULT_SETTINGS.browser.channel
}

/** Coerce one positive-integer field, keeping the default when invalid. */
function count(value: unknown, fallback: number): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback
  const floored = Math.floor(value)
  // A fractional value below 1 floors to 0, and 0 is not "very few" in either place these are
  // used: as a history entry cap it means `slice(len - 0)`, i.e. keep nothing, so a hand-typed
  // `0.5` silently wiped the history file on the next rewrite. Anything that survives the
  // floor has to still be a usable limit.
  return floored > 0 ? floored : fallback
}

/** Read one nested section of an unknown document, or an empty object. */
/**
 * Read one section of the document, distinguishing ABSENT from UNREADABLE.
 *
 * Absent (the key is not there at all) is a document written before the section existed, and
 * the defaults apply — that is the documented behaviour. Present-but-not-an-object
 * (`"actions": false`, `null` from a truncated write, a stray string) is a document this code
 * cannot read, and returning `{}` for it made every gate inside look absent, so each one took
 * its permissive default. A whole section mistyped is exactly the shape a careless hand edit
 * produces, and it opened every capability the section was there to bound.
 * @param source - the parsed document.
 * @param key - the section name.
 * @returns the section, or undefined when it is present but not an object.
 */
function section(source: Record<string, unknown>, key: string): Record<string, unknown> | undefined {
  const value = source[key]
  if (value === undefined) return {}
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

/**
 * Resolve a raw settings document (already parsed, shape unknown) into the full
 * document, field by field. Unknown keys are dropped: the file is not a place to
 * smuggle configuration.
 * @param raw - the parsed file contents.
 * @returns the resolved settings.
 */
export function resolveSettings(raw: unknown, warn?: (message: string) => void): BrowserSettings {
  const source = typeof raw === 'object' && raw !== null ? raw as Record<string, unknown> : {}
  const history = section(source, 'history')
  const cookies = section(source, 'cookies')
  const ui = section(source, 'ui')
  const vision = section(source, 'vision')
  const credentials = section(source, 'credentials')
  const browser = section(source, 'browser')
  const actions = section(source, 'actions')
  // A section that is present but unreadable refuses its gates rather than defaulting them
  // open. The rest of a broken section keeps its defaults: refusing history or presentation
  // would punish the user for a bad file without protecting anything.
  const credentialsUsable = credentials ?? {}
  const actionsUsable = actions ?? {}
  return {
    history: {
      enabled: bool(history?.enabled, DEFAULT_SETTINGS.history.enabled),
      maxEntries: count(history?.maxEntries, DEFAULT_SETTINGS.history.maxEntries),
      maxAgeDays: count(history?.maxAgeDays, DEFAULT_SETTINGS.history.maxAgeDays),
    },
    cookies: { persist: bool(cookies?.persist, DEFAULT_SETTINGS.cookies.persist) },
    ui: {
      autoExpandOnce: bool(ui?.autoExpandOnce, DEFAULT_SETTINGS.ui.autoExpandOnce),
      closeWithSession: bool(ui?.closeWithSession, DEFAULT_SETTINGS.ui.closeWithSession),
      virtualCursor: bool(ui?.virtualCursor, DEFAULT_SETTINGS.ui.virtualCursor),
    },
    vision: { strategy: vision?.strategy === 'nonVisual' ? 'nonVisual' : DEFAULT_SETTINGS.vision.strategy },
    browser: {
      channel: resolveChannel(browser?.channel, warn),
      headless: resolveHeadless(browser?.headless, warn),
    },
    credentials: {
      // `gate` returns false for anything present-and-not-a-boolean, so an unreadable section
      // is refused here for free: the section itself is the "present but wrong" value.
      allowRead: credentials === undefined
        ? false
        : gate(credentialsUsable.allowRead, DEFAULT_SETTINGS.credentials.allowRead),
    },
    actions: {
      allowExecute: actions === undefined
        ? false
        : gate(actionsUsable.allowExecute, DEFAULT_SETTINGS.actions.allowExecute),
      allowDownload: actions === undefined
        ? false
        : gate(actionsUsable.allowDownload, DEFAULT_SETTINGS.actions.allowDownload),
      allowCredentialWrite: actions === undefined
        ? false
        : gate(actionsUsable.allowCredentialWrite, DEFAULT_SETTINGS.actions.allowCredentialWrite),
    },
  }
}

/**
 * File-backed settings with an in-memory snapshot. Reads re-stat the file so an
 * edit from another process (or the settings panel writing through a second
 * code path) is picked up without a restart; writes are atomic enough for a
 * single-writer plugin and never throw at the caller.
 */
export class SettingsStore {
  private cached: BrowserSettings | undefined
  /** Last observed mtime, used to invalidate the cache on external edits. */
  private cachedMtimeMs = -1

  /**
   * @param file - settings file path (defaults beside the browser profile).
   */
  constructor(private readonly file: string = settingsPath(), private readonly log?: (message: string) => void) {}

  /** Path this store reads and writes. */
  path(): string {
    return this.file
  }

  /**
   * Current settings, re-read when the file changed on disk.
   * @returns the resolved settings document.
   */
  get(): BrowserSettings {
    let mtimeMs = -1
    try {
      // stat directly: existsSync costs about thirteen times what the stat does, and the
      // stat already throws when the file is missing — which the catch below handles.
      mtimeMs = statSync(this.file).mtimeMs
    } catch {
      // Unreadable file: fall through to defaults below.
      mtimeMs = -1
    }
    // Return the cache BEFORE reading. The read used to happen first "just in case", which
    // made the cache pointless: every call paid for a synchronous read of the whole file and
    // then discarded it. This is on the path of every tool call that consults a setting, so
    // it was a stat plus a read per call where a single stat will do.
    if (this.cached !== undefined && mtimeMs === this.cachedMtimeMs) return this.cached

    let text: string | undefined
    if (mtimeMs !== -1) {
      try {
        text = readFileSync(this.file, 'utf8')
      } catch {
        // It was there a moment ago (the stat above) and cannot be read now: permissions, a
        // lock, a directory in the way. That is not "no document" — the file is not absent, so
        // what it said is unknown, and unknown resolves to the refusing document.
        this.cached = SETTINGS_WHEN_UNREADABLE
        this.cachedMtimeMs = mtimeMs
        return this.cached
      }
    }
    try {
      // A leading BOM is what ordinary Windows editors (Notepad, PowerShell's
      // `Set-Content -Encoding utf8`) leave behind, and `JSON.parse` rejects it.
      // Without this strip, hand-editing the settings file silently discarded every
      // value in it: the document looked correct, and the plugin quietly ran on
      // defaults — including switches the user had just turned off.
      const body = text?.replace(/^\uFEFF/, '')
      this.cached = body === undefined ? DEFAULT_SETTINGS : resolveSettings(JSON.parse(body), m => this.log?.(m))
    } catch {
      // A document that EXISTS but cannot be parsed is not the same as no document at all: the
      // first is a corrupted or half-written file whose contents were the operator's decisions,
      // the second is a first run. Resolving both to the defaults meant a kill during the write,
      // or one stray character, silently reopened the capabilities that had been switched off —
      // so this side refuses them instead (see SETTINGS_WHEN_UNREADABLE).
      this.cached = SETTINGS_WHEN_UNREADABLE
    }
    this.cachedMtimeMs = mtimeMs
    return this.cached
  }

  /**
   * Merge a partial patch into the stored document and persist it.
   * @param patch - the fields to change (unknown keys are ignored).
   * @returns the settings after the merge.
   */
  update(patch: unknown): BrowserSettings {
    const current = this.get()
    const merged = resolveSettings(deepMerge(current as unknown as Record<string, unknown>, patch), m => this.log?.(m))
    try {
      mkdirSync(dirname(this.file), { recursive: true })
      writeFileAtomic(this.file, `${JSON.stringify(merged, null, 2)}\n`)
    } catch (error) {
      // Do NOT publish the new value as cached, and do not pretend the file changed: a
      // reader compares the file's mtime against this stamp, so stamping "now" on a failed
      // write made the next get() re-read the file and silently revert the user's change.
      // Clear the cache before failing: the value on disk is still the old one, so leaving
      // the merged document cached would hand the next reader something that does not exist —
      // and the stamp would make it look fresh until the mtime comparison rolled it back.
      this.cached = undefined
      this.cachedMtimeMs = -1
      throw new Error(`dsh-builtin-browser: settings could not be saved: ${error instanceof Error ? error.message : String(error)}`)

    }
    return merged
  }
}

/**
 * Replace a file's contents atomically: write a sibling temporary file, then rename it over
 * the target.
 *
 * `writeFileSync(target, …)` truncates and rewrites in place, so a crash, a full disk or an
 * antivirus lock in the middle leaves HALF a JSON document. That used to be silent: the reader
 * resolved an unparseable file to the defaults, so a torn write flipped `credentials.allowRead`
 * and the action switches back ON, and the next successful update wrote those defaults to disk
 * for good. The read side no longer does that (see {@link SETTINGS_WHEN_UNREADABLE}) — but the
 * write side still has to stop producing torn files at all, because half a document is not
 * something this plugin should ever leave behind.
 *
 * The rename is the commit point: a reader sees either the old document or the new one,
 * never a partial one. It stays in the same directory so the rename is atomic on Windows
 * as well as POSIX (`renameSync` maps to MoveFileEx there: same-volume replaces are
 * atomic, cross-volume ones are not supported at all).
 *
 * The temporary is written with a unique suffix rather than a fixed `.tmp`, so two writers
 * (the settings panel and a second DSH process) cannot rename each other's half-written
 * file into place. Shared with the history store, which had the same hole.
 * @param file - the target path.
 * @param contents - the complete new document.
 */
export function writeFileAtomic(file: string, contents: string): void {
  const temporary = `${file}.${process.pid}.${Math.random().toString(36).slice(2, 10)}.tmp`
  try {
    writeFileSync(temporary, contents)
    renameSync(temporary, file)
  } catch (error) {
    // The rename is the commit point, so a failure before it leaves the target untouched —
    // only the temporary has to go, and it must not be left behind as garbage.
    try { rmSync(temporary, { force: true }) } catch { /* the temp is already the least of it */ }
    throw error
  }
}

/** One-level-deep merge over the settings sections (patch wins). */
function deepMerge(base: Record<string, unknown>, patch: unknown): Record<string, unknown> {
  if (typeof patch !== 'object' || patch === null) return base
  const result: Record<string, unknown> = { ...base }
  for (const [key, value] of Object.entries(patch as Record<string, unknown>)) {
    const existing = result[key]
    if (typeof value === 'object' && value !== null && typeof existing === 'object' && existing !== null) {
      result[key] = { ...existing as Record<string, unknown>, ...value as Record<string, unknown> }
    } else {
      result[key] = value
    }
  }
  return result
}
