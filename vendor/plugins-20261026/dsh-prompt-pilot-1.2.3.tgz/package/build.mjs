import { readFile, writeFile } from 'node:fs/promises';
const logic=(await readFile(new URL('./client-logic.js',import.meta.url),'utf8')).replace(/^export /gm,'');
const source=await readFile(new URL('./client-source.js',import.meta.url),'utf8');
// One authored client; emitted artifact remains self-contained for DSH's loader.
const output=source.replace("    const NS = 'prompt-pilot';",logic+"\n    const NS = 'prompt-pilot';");
await writeFile(new URL('./client.js',import.meta.url),output);
// Keep the previously installed export current until the Host metadata cache reloads.
await writeFile(new URL('./client-inline.js',import.meta.url),output);
console.log('Built client.js (and legacy client-inline.js) from client-source.js + client-logic.js');
