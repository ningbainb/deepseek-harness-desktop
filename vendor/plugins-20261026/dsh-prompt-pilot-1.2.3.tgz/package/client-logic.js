// Shared pure browser logic, also imported directly by Node regression tests.
export function normalizePreferences(value) {
  let route='';
  try { const r=JSON.parse(value?.route||'null');if(typeof r?.provider==='string'&&r.provider&&typeof r.model==='string'&&r.model)route=JSON.stringify({provider:r.provider,model:r.model}); } catch {}
  return {enabled:value?.enabled!==false,route,budget:value?.budget==='balanced'?'balanced':'eco'};
}
export function escapeCSS(text) { return Array.from(text,c=>'\\'+c.codePointAt(0).toString(16)+' ').join(''); }
export function ghostCSS(sessionId, suggestion) {
  const owner='[data-conversation-session="'+escapeCSS(sessionId)+'"]';
  const native=owner+' [data-composer-card]:has(.pp-inline-active) [data-composer-placeholder]';
  return `${native}{visibility:hidden;pointer-events:none}${native}::after{content:"${escapeCSS(suggestion)}";visibility:visible;position:absolute;inset:0;padding:inherit;font:inherit;line-height:inherit;letter-spacing:inherit;white-space:pre-wrap;overflow:hidden;color:var(--dsw-alias-label-secondary);opacity:.62;pointer-events:none}${owner} [data-composer-card]:has([data-composer-composing=true]) [data-composer-placeholder]::after{visibility:hidden}`;
}
export function canShowGhost(input, result, key) {
  return input.enabled&&!input.running&&!input.blocked&&input.draft===''&&input.attachments===0&&input.phase==='plain'&&result?.key===key&&typeof result.suggestion==='string'&&!!result.suggestion;
}
