# 智能下一句 / Prompt Pilot

DSH Cordis 插件。每轮成功回复后，在原生输入框的占位文字位置淡灰显示下一句建议，不显示额外提示栏、加载状态或按钮，不占布局空间。空草稿时按 Tab 填入，Esc 隐藏；开始输入即隐藏，不自动发送，不覆盖草稿。设置 → 智能下一句提供启停、跟随当前模型或单独选择模型、省量/均衡上下文预算。偏好仅存当前浏览器 localStorage，不修改主会话模型。

省量：最近至多六条人类/助手文字，总计 4000 字符，输出预算 256 token。均衡：10000 字符、512 token。额外请求不包含工具日志、思考、系统提示词或附件。缓存以会话、完成轮次、模型、预算为键，进程内至多64项；25秒超时，不自动重试。服务商真实 usage 保存在预测结果中，不在输入框显示；没有 usage 时不猜测。上下文按角色分配，最近用户意图至少预留约 1/3 预算（足够长时），长消息保留首尾。推理努力只从服务商声明中选择 off/minimal/low 的最低档。推理型模型可能把输出预算用于思考，导致空输出；可以选择较快非推理模型。结果不会写入主模型对话；命令调用会留下标准 command 生命周期记录。

当前版本通过 conversation.input.overlay 正式插槽装载组件，CSS 伪元素复用原生 placeholder 的字体、位置及内边距，没有修改原生编辑器 DOM 或草稿。依赖宿主 data-composer-placeholder 语义标记；宿主更改该标记时需要适配。快捷键监听仅对所属会话中空草稿、无附件、plain 阶段、聚焦原生输入框生效；IME 输入期间隐藏。卸载清理监听器及组件样式。

## 参考
- Open WebUI: https://github.com/open-webui/open-webui
- Follow-Up Prompts: https://docs.openwebui.com/features/chat-conversations/chat-features/follow-up-prompts/
- CopilotKit: https://github.com/CopilotKit/CopilotKit
- Suggestions lifecycle: https://docs.copilotkit.ai/reference/hooks/useConfigureSuggestions

仅参考公开行为和设计思路，代码独立实现；未复制这些项目代码或引入完整框架。没有依据声称 Codex 私有桌面预测后端已开源，也不假定其免费额度适用于 DSH。

源码以 client-source.js + client-logic.js 为准，`node build.mjs` 生成固定入口 client.js（同时维护旧入口 client-inline.js，兼容已缓存的旧导出）。不要直接改构建产物。测试：`node --test *.test.mjs`。安装目录由 DSH plugin_manager install_bundle 管理。已加载 Host JS 模块更换后需要重启 DSH 才能保证新代码生效；客户端挂载与灰字交互仍需真实已认证页面验收。

切换会话/轮次/模型立即排除旧结果；用户开始输入或按 Esc 会记住本轮忽略状态，删空后不再弹出。输入期间取消待发/进行中的预测；不自动重试。中文 compositionend 后额外50ms不捕获 Tab，pending interaction 时不展示建议。
