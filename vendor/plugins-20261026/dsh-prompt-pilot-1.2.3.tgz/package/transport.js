// Internal JSON endpoints; deliberately bypass Commands and the session log.
export function createCatalogRoute(ctx) {
  return {path:'/api/prompt-pilot/catalog',methods:['GET'],requestBody:'buffered',async fetch(){
    try{return Response.json(await ctx.sessionController.modelCatalog(),{headers:{'cache-control':'no-store'}});}
    catch(error){return Response.json({ok:false,error:{code:'CATALOG_FAILED',message:String(error?.message||error)}},{status:500});}
  }};
}
export function createPredictionRoute(ctx, operations) {
  return {
    path: '/api/prompt-pilot', methods: ['POST'], requestBody: 'buffered',
    async fetch(request) {
      const reply=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'content-type':'application/json','cache-control':'no-store'}});
      try {
        const input=await request.json();
        if(!input||typeof input.sessionId!=='string'||input.sessionId.length>512||!input.request||typeof input.request!=='object')return reply({ok:false,error:{code:'INVALID_REQUEST',message:'Expected sessionId and request.'}},400);
        let agent=ctx.agents.get(input.sessionId);
        if(!agent){
          const resolved=await ctx.sessionController.resolveAgent(input.sessionId);
          if(resolved.error)return reply({ok:false,error:{code:resolved.error.code,message:resolved.error.message}},409);
          agent=resolved.agent;
        }
        if(request.signal.aborted)return reply({ok:false,error:{code:'ABORTED',message:'Request cancelled.'}},409);
        return reply(await operations.run({...input.request,sessionId:input.sessionId},agent,request.signal));
      } catch(error) {
        return reply({ok:false,error:{code:'PREDICTION_FAILED',message:String(error?.message||error).slice(0,1000)}},400);
      }
    },
  };
}
