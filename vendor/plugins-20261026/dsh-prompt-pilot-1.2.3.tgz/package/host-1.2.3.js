import { z } from 'zod';
import { PROJECTION_KEY, initialState, foldContext, createOperations } from './core.js?generation=1.2.3';
import { createPredictionRoute, createCatalogRoute } from './transport.js';

export const inject = ['connection', 'agents', 'tools', 'llm', 'sessionProjections', 'sessionController'];

export function apply(ctx) {
  const message = z.object({ role: z.enum(['user', 'assistant']), text: z.string().max(10000) });
  const viewSchema = z.object({ completedSeq: z.number().int(), hasContext: z.boolean() });
  ctx.sessionProjections.register({
    key: PROJECTION_KEY,
    stateVersion: 2,
    stateSchema: z.object({ messages: z.array(message).max(6), completedSeq: z.number().int(), latestTextSeq: z.number().int(), ready: z.boolean(), view: viewSchema }),
    init: initialState,
    apply: foldContext,
    wire: { viewSchema, view: state => state.view },
  });
  const operations = createOperations(ctx);
  ctx.effect(() => () => operations.dispose());
  ctx.connection.fetch.register(createPredictionRoute(ctx, operations));
  ctx.connection.fetch.register(createCatalogRoute(ctx));
  ctx.tools.register({
    name: 'prompt_pilot',
    description: 'Suggest a next human message from the latest completed, idle session turn, or list available model routes. Returns suggestion and usage or an explicit error. Does not send messages or change settings.',
    parameters: {
      type: 'object', additionalProperties: false, required: ['action'],
      properties: {
        action: { type: 'string', enum: ['predict', 'catalog'] },
        budget: { type: 'string', enum: ['eco', 'balanced'], description: 'Required for predict: eco uses up to 4000 context characters and 256 output tokens; balanced uses 10000 and 512.' },
        provider: { type: 'string', description: 'Optional provider route; supply together with model. Defaults to the invoking session model.' },
        model: { type: 'string', description: 'Exact model ID paired with provider.' },
        sessionId: { type: 'string', description: 'Optional assertion of the invoking session ID; cannot target another session.' },
      },
    },
    output: { schema: { type: 'object' }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
    timeoutMs: 26000,
    isConcurrencySafe: () => true,
    execute: (args, exec) => operations.run(args, exec.agent, exec.signal),
  });
}
