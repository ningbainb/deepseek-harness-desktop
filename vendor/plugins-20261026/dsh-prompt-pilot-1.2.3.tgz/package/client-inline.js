window.__ModuleLoader__.load({
  id: '@local/dsh-prompt-pilot',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
// Shared pure browser logic, also imported directly by Node regression tests.
function normalizePreferences(value) {
  let route='';
  try { const r=JSON.parse(value?.route||'null');if(typeof r?.provider==='string'&&r.provider&&typeof r.model==='string'&&r.model)route=JSON.stringify({provider:r.provider,model:r.model}); } catch {}
  return {enabled:value?.enabled!==false,route,budget:value?.budget==='balanced'?'balanced':'eco'};
}
function escapeCSS(text) { return Array.from(text,c=>'\\'+c.codePointAt(0).toString(16)+' ').join(''); }
function ghostCSS(sessionId, suggestion) {
  const owner='[data-conversation-session="'+escapeCSS(sessionId)+'"]';
  const native=owner+' [data-composer-card]:has(.pp-inline-active) [data-composer-placeholder]';
  return `${native}{visibility:hidden;pointer-events:none}${native}::after{content:"${escapeCSS(suggestion)}";visibility:visible;position:absolute;inset:0;padding:inherit;font:inherit;line-height:inherit;letter-spacing:inherit;white-space:pre-wrap;overflow:hidden;color:var(--dsw-alias-label-secondary);opacity:.62;pointer-events:none}${owner} [data-composer-card]:has([data-composer-composing=true]) [data-composer-placeholder]::after{visibility:hidden}`;
}
function canShowGhost(input, result, key) {
  return input.enabled&&!input.running&&!input.blocked&&input.draft===''&&input.attachments===0&&input.phase==='plain'&&result?.key===key&&typeof result.suggestion==='string'&&!!result.suggestion;
}

    const NS = 'prompt-pilot';
    const dictionaries = {
      zh: {title:'智能下一句', settings:'预测设置', enabled:'自动预测', follow:'跟随当前对话模型', eco:'省量 · 最近 4,000 字符', balanced:'均衡 · 最近 10,000 字符', loading:'正在预测下一句…', waiting:'回复结束后预测下一句', accept:'Tab 采纳', dismiss:'隐藏建议', empty:'本轮没有合适的建议', off:'预测已关闭', model:'推荐模型', budget:'上下文预算', close:'关闭设置', retry:'重试', failed:'预测失败', note:'仅填入草稿，不会发送。每轮至多一次短请求；不会随按键调用模型。', stale:'草稿已变化，未填入建议', cached:'缓存', tokens:'token', select:'点击填入建议'},
      en: {title:'Prompt Pilot', settings:'Prediction settings', enabled:'Auto-predict', follow:'Follow conversation model', eco:'Eco · last 4,000 characters', balanced:'Balanced · last 10,000 characters', loading:'Predicting your next prompt…', waiting:'Predicts after the reply finishes', accept:'Tab to accept', dismiss:'Dismiss suggestion', empty:'No suitable suggestion this turn', off:'Predictions off', model:'Suggestion model', budget:'Context budget', close:'Close settings', retry:'Retry', failed:'Prediction failed', note:'Inserts a draft without sending. At most one short request per turn; never calls the model on keystrokes.', stale:'Draft changed; suggestion was not inserted', cached:'Cached', tokens:'tokens', select:'Insert suggestion'}
    };
    function readPrefs() {
      try { return normalizePreferences(JSON.parse(localStorage.getItem('dsh-prompt-pilot-v1')||'{}')); }
      catch { return normalizePreferences(null); }
    }
    return {
      inject:['slots','locale','sessions'],
      apply(ctx) {
        // Locale.register returns a disposer; unlike slots it is not effect-owned.
        // One atomic bilingual registration, explicitly owned by this plugin run.
        ctx.effect(()=>ctx.locale.register(NS,dictionaries));
        const t=ctx.locale.bind(NS);
        const listeners=new Set();
        let preference=readPrefs();
        const dismissedKeys=new Map();
        const diagnostics=new Map();
        const diagnosticListeners=new Set();
        let diagnosticSnapshot=[];
        const observeDiagnostics=fn=>{diagnosticListeners.add(fn);return()=>diagnosticListeners.delete(fn);};
        const report=(sessionId,status,detail='')=>{
          diagnostics.set(sessionId,{sessionId,status,detail,time:new Date().toLocaleTimeString()});
          if(diagnostics.size>32)diagnostics.delete(diagnostics.keys().next().value);
          diagnosticSnapshot=Array.from(diagnostics.values()).reverse();
          for(const fn of diagnosticListeners)fn();
        };
        const subscribe=fn=>{listeners.add(fn);return()=>listeners.delete(fn);};
        const snapshot=()=>preference;
        const updatePrefs=patch=>{preference=normalizePreferences({...preference,...patch});try{localStorage.setItem('dsh-prompt-pilot-v1',JSON.stringify(preference));}catch{}for(const fn of listeners)fn();};
        function Settings() {
          React.useSyncExternalStore(fn=>ctx.locale.subscribe(fn),()=>ctx.locale.getSnapshot());
          const prefs=React.useSyncExternalStore(subscribe,snapshot);
          const diagnosticRows=React.useSyncExternalStore(observeDiagnostics,()=>diagnosticSnapshot);
          const zh=ctx.locale.getSnapshot().active.startsWith('zh');
          const [catalog,setCatalog]=React.useState(null);
          const [error,setError]=React.useState('');
          React.useEffect(()=>{
            const controller=new AbortController();
            (async()=>{
              try {
                const response=await fetch(new URL('api/prompt-pilot/catalog',document.baseURI),{credentials:'same-origin',signal:controller.signal});
                const value=await response.json();
                if(!response.ok||value?.ok===false)throw new Error(value?.error?.message||'Model catalog unavailable');
                if(!controller.signal.aborted)setCatalog(value);
              } catch(e){if(!controller.signal.aborted)setError(String(e.message||e));}
            })();
            return()=>controller.abort();
          },[]);
          const style={display:'grid',gap:18,padding:20,color:'var(--dsw-alias-label-primary)'};
          const selectStyle={font:'inherit',maxWidth:'100%',padding:'6px 10px',border:'1px solid var(--dsw-alias-border-l1)',borderRadius:6,color:'var(--dsw-alias-label-primary)',background:'var(--dsw-alias-bg-layer-1)'};
          return h('section',{style},h('h2',null,t('title')),
            h('label',null,h('input',{type:'checkbox',checked:prefs.enabled,onChange:e=>updatePrefs({enabled:e.target.checked})}),' '+t('enabled')),
            h('label',null,t('model'),' ',h('select',{style:selectStyle,value:prefs.route,onChange:e=>updatePrefs({route:e.target.value})},h('option',{value:''},t('follow')),...(catalog?.groups||[]).map(g=>h('optgroup',{key:g.id,label:g.name},...g.models.map(m=>h('option',{key:m.id,value:JSON.stringify({provider:g.id,model:m.id})},m.name||m.id)))))),
            h('label',null,t('budget'),' ',h('select',{style:selectStyle,value:prefs.budget,onChange:e=>updatePrefs({budget:e.target.value})},h('option',{value:'eco'},t('eco')),h('option',{value:'balanced'},t('balanced')))),
            h('p',{style:{color:'var(--dsw-alias-label-secondary)'}},t('note')),error?h('p',{role:'alert'},error):null,
            h('details',null,h('summary',null,zh?'桌面运行诊断（不记录对话内容）':'Desktop diagnostics (no message content)'),
              diagnosticRows.length?h('ul',null,...diagnosticRows.map(row=>h('li',{key:row.sessionId,style:{overflowWrap:'anywhere',margin:'8px 0'}},`${row.time} · ${row.sessionId.slice(0,12)} · ${row.status}${row.detail?' · '+row.detail:''}`))):h('p',null,zh?'暂无会话组件运行记录':'No composer activity recorded')));
        }
        function PilotEntry(props){return h(Pilot,{...props,key:props.sessionId});}
        function Pilot(props) {
          React.useSyncExternalStore(fn=>ctx.locale.subscribe(fn),()=>ctx.locale.getSnapshot());
          const prefs=React.useSyncExternalStore(subscribe,snapshot);
          const [result,setResult]=React.useState(null);
          const [dismissed,setDismissed]=React.useState(false);
          const draft=props.useInput(s=>s.draft);
          const phase=props.useInput(s=>s.phase);
          const attachments=props.useInput(s=>s.attachmentIds.length);
          const running=props.useSession(s=>s.running);
          const blank=props.useSession(s=>s.blank);
          const boundary=props.useProjection('promptPilotContext',s=>s?.completedSeq??-1);
          const modelJSON=props.useProjection('modelSelection',s=>JSON.stringify(s?.next??s?.lastUsed??null));
          const pending=props.useSessionStatus(s=>!!s.get(props.sessionId)?.pendingInteraction);
          const key=JSON.stringify([props.sessionId,boundary,prefs.route||modelJSON,prefs.budget]);
          const requestRef=React.useRef(null);
          const recentlyComposing=React.useRef(0);
          const generation=React.useRef(0);
          const latest=React.useRef({draft,phase,attachments,running});
          latest.current={draft,phase,attachments,running,blocked:pending,key};
          async function call(request,signal) {
            const response=await fetch(new URL('api/prompt-pilot',document.baseURI),{
              method:'POST',credentials:'same-origin',signal,
              headers:{'content-type':'application/json'},
              body:JSON.stringify({sessionId:props.sessionId,request})
            });
            const data=await response.json();
            if(!response.ok&&data?.ok!==false)throw new Error('Prediction transport failed: '+response.status);
            if(data?.ok===false) throw new Error(data.error?.message||'Prediction failed');
            return data;
          }
          React.useEffect(()=>{
            setResult(null);setDismissed(dismissedKeys.get(props.sessionId)===key);
            const id=++generation.current;
            const skip=!prefs.enabled?'预测关闭':running?'主回复进行中':blank?'空对话，等待首轮回复':boundary<0?'缺少完成轮次投影':pending?'等待交互确认':dismissedKeys.get(props.sessionId)===key?'本轮已忽略':null;
            report(props.sessionId,skip?'未触发':'等待预测',skip||'');
            if(skip)return;
            // Only the turn/model/config boundary triggers generation, not draft edits.
            const controller=new AbortController();
            requestRef.current=controller;
            let timer=setTimeout(async()=>{
              if(controller.signal.aborted||latest.current.key!==key||latest.current.blocked||latest.current.draft!==''||latest.current.attachments!==0||latest.current.phase!=='plain') return;

              try {
                const route=prefs.route?JSON.parse(prefs.route):JSON.parse(modelJSON);
                report(props.sessionId,'请求中');
                const value=await call({action:'predict',budget:prefs.budget,...route?{provider:route.provider,model:route.model}:{}},controller.signal);
                if(!controller.signal.aborted&&id===generation.current){setResult({...value,key});report(props.sessionId,value.suggestion?'已收到建议':'空建议',value.model||'');}
              } catch(e) {if(!controller.signal.aborted)report(props.sessionId,'请求失败',String(e.message||e));}
            },650);
            return ()=>{clearTimeout(timer);controller.abort();};
          },[props.sessionId,boundary,running,blank,prefs.enabled,prefs.route,prefs.budget,modelJSON,pending]);
          const dismiss=()=>{dismissedKeys.set(props.sessionId,key);if(dismissedKeys.size>64)dismissedKeys.delete(dismissedKeys.keys().next().value);setDismissed(true);requestRef.current?.abort();};
          React.useEffect(()=>{if(draft!==''||attachments>0) dismiss();},[draft,attachments,key]);
          const visible=!dismissed&&dismissedKeys.get(props.sessionId)!==key&&canShowGhost({enabled:prefs.enabled,running,blocked:pending,draft,attachments,phase},result,key);
          function accept() {
            const current=latest.current;
            if(!visible||current.key!==result?.key||current.blocked||current.draft!==''||current.running||current.attachments||current.phase!=='plain') return false;
            const span=props.inputActions.captureInsertion();
            if(span.start!==0||span.end!==0) return false;
            const inserted=props.inputActions.insertText(result.suggestion,span);
            if(inserted){dismiss();report(props.sessionId,'Tab 已填入草稿（未发送）');}
            else report(props.sessionId,'Tab 未填入','输入框版本或选择范围已改变');
            return inserted;
          }
          React.useEffect(()=>{
            if(!visible) return;
            const listener=e=>{
              if(Date.now()<recentlyComposing.current||e.defaultPrevented||e.isComposing||e.keyCode===229||e.repeat||e.shiftKey||e.ctrlKey||e.metaKey||e.altKey) return;
              // Scope to the focused native composer, never to other inputs or windows.
              const target=e.target;
              if(!target?.isContentEditable||!target.hasAttribute('data-composer-input')||target.closest('[data-conversation-session]')?.getAttribute('data-conversation-session')!==props.sessionId) return;
              if(e.key==='Tab'&&accept()){e.preventDefault();e.stopPropagation();}
              else if(e.key==='Escape'){dismiss();e.preventDefault();e.stopPropagation();}
            };
            const onCompositionEnd=()=>{recentlyComposing.current=Date.now()+50;};
            document.addEventListener('compositionend',onCompositionEnd,true);
            document.addEventListener('keydown',listener,true);
            return ()=>{document.removeEventListener('keydown',listener,true);document.removeEventListener('compositionend',onCompositionEnd,true);};
          },[visible,result]);
          // Use the native placeholder's exact font, padding and geometry. The
          // suggested text is CSS-only: it never becomes draft/editor content.
          // No host DOM writes, measurements, layout shifts, or competing input.
          if(!visible) return null;
          return h(React.Fragment,null,
            h('span',{className:'pp-inline-active','aria-hidden':true,style:{display:'none'}}),
            h('style',null,ghostCSS(props.sessionId,result.suggestion)));
        }
        ctx.slots.inject('conversation.input.overlay',()=>ctx.slots.register({name:'conversation.input.overlay',id:'prompt-pilot-inline',order:90},PilotEntry));
        ctx.slots.inject('settings.section',()=>ctx.slots.register({name:'settings.section',id:'prompt-pilot',order:61,label:()=>t('title')},Settings));
      }
    };
  }
});
