# 素材来源

- `spritesheet.png`、`idle.png`：本次大肥鱼工作流生成并验证的73帧精灵图及其待机帧。
- `sleeping.png`：同一工作流生成的困困贴纸。
- `rua.gif`、`bubble-petpet.gif`、`bubble-money1.gif`：分别使用本次生成的跳跃、挥手、失落动画；保留上游文件名用于兼容代码中的内置资源槽。
- `press-a.wav`、`release-a.wav`、`press-b.wav`、`release-b.wav`、`notice.wav`：本项目合成的100毫秒、低音量正弦提示音；不是原项目音效。

角色参考图由用户提供。本文件记录素材出处，不扩大参考图或第三方角色可能涉及的权利范围。上游美术和音效未复制到本包。
